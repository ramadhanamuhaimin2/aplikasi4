<div class="container">
    <table style="width:40%">
        <tr class="font-weight-bold">
            <th>ID Buku</th>
            <th>: <?= $buku['id_buku'] ?></th>
        </tr>
        <tr class="font-weight-bold">
            <td>Judul Buku</td>
            <td>: <?= $buku['judul_buku'] ?></td>
        </tr>
        <tr>
            <td>Penulis</td>
            <td>: <?= $buku['penulis'] ?></td>
        </tr>
        <tr>
            <td>Tahun Terbit</td>
            <td>: <?= $buku['tahun_terbit'] ?></td>
        </tr>
        <tr>
            <td>Penerbit</td>
            <td>: <?= $buku['penerbit'] ?></td>
        </tr>
        <tr>
            <td>Kategori</td>
            <td>: <?= $buku['kategori'] ?></td>
        </tr>
        <tr>
            <td>Jumlah Buku</td>
            <td>: <?= $buku['jumlah_buku'] ?></td>
        </tr>
        <tr>
            <td>Lokasi Buku</td>
            <td>: <?= $buku['lokasi_buku'] ?></td>
        </tr>
    </table> <br>
</div>