<style>
.tengah {
    margin-top: 25%;
}
</style>

<div class="container">
    <h2 class="text-center text-dark bg-white rounded shadow p-3 tengah">
        Available soon ... ;)
    </h2>
</div>