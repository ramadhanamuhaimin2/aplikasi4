# Project Perpustakaan

Repository untuk project perpustakaan mata kuliah Pemrograman Web Lanjut

Dibangun menggunakan bahasa pemrograman PHP dengan Framework Codeigniter